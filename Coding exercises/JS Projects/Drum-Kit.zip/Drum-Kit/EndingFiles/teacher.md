## Code Along: Creating a JavaScript Drum Kit

In this code along, we'll build a simple JavaScript Drum Kit that plays different drum sounds when you press specific keys on your keyboard. We'll explain each step of the code to help you understand how it works.

### Step 1: Define the `playSound` function

```javascript
function playSound(e) {
  // 2. Get the audio element corresponding to the pressed key using its keyCode.
  const audio = document.querySelector(`audio[data-key="${e.keyCode}"]`);
  
  // 3. Get the HTML element (key) associated with the pressed key.
  const key = document.querySelector(`div[data-key="${e.keyCode}"]`);
  
  // 4. If there is no audio element for the key, exit the function.
  if (!audio) return;

  // 5. Reset the audio to the beginning (rewind).
  audio.currentTime = 0;

  // 6. Play the audio.
  audio.play();

  // 7. Add the CSS class 'playing' to the key element to apply a visual effect.
  key.classList.add('playing');
}
```

- `playSound` is a function that takes an event `e` as an argument.
- It uses the `e.keyCode` property to determine which key was pressed and selects the corresponding `<audio>` element and `<div>` key element using `querySelector`.
- If there is no audio element for the pressed key, the function exits.
- It resets the audio to the beginning, plays it, and adds the CSS class 'playing' to the key element for a visual effect.

### Step 2: Define the `removeTransition` function

```javascript
function removeTransition(e) {
  // 9. Check if the property that triggered the event is 'transform'.
  if (e.propertyName !== 'transform') return;

  // 10. Remove the 'playing' class from the element that triggered the transition end event.
  this.classList.remove('playing');
}
```

- `removeTransition` is a function that takes an event `e` as an argument.
- It checks if the property that triggered the event is 'transform'. If not, it exits the function.
- It removes the 'playing' class from the element that triggered the transition end event.

### Step 3: Get all elements with the class 'key'

```javascript
// 11. Get all elements with the class 'key' and store them in the 'keys' array.
const keys = Array.from(document.querySelectorAll('.key'));
```

- This code selects all HTML elements with the class 'key' using `querySelectorAll` and converts the resulting NodeList into an array using `Array.from`.
- The selected elements are stored in the 'keys' array for later use.

### Step 4: Add event listeners

```javascript
// 12. Add a 'transitionend' event listener to each element in the 'keys' array
//     to remove the 'playing' class when the transition ends.
keys.forEach(key => key.addEventListener('transitionend', removeTransition));

// 13. Add a 'keydown' event listener to the window to trigger the playSound function when a key is pressed.
window.addEventListener("keydown", playSound);
```

- We loop through each element in the 'keys' array and add a 'transitionend' event listener that calls the `removeTransition` function when the transition ends. This removes the 'playing' class from the key element when the visual effect is finished.
- We add a 'keydown' event listener to the window, which triggers the `playSound` function when a key is pressed. This allows us to listen for key presses globally.

That's it! You've created a simple JavaScript Drum Kit that plays drum sounds when you press keys on your keyboard and adds a visual effect to the corresponding key element. This code along demonstrates the use of `querySelector`, if statements, and functions in JavaScript. Feel free to customize the drum sounds and visuals to create your own unique drum kit. Happy coding!