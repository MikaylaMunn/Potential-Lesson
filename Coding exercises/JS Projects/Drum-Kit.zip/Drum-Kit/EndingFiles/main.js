// Listening for a keydown event
      
function playSound (e) {
    // Getting the audio element for that key
    const audio = document.querySelector(`audio[data-key="${e.keyCode}"]`);
    // adding the key
    const key = document.querySelector(`.key[data-key="${e.keyCode}"]`);
    // IF no audio then return to stop function
    if (!audio) return;
    audio.currentTime = 0; // rewinds it to the start
    // play the audio
    audio.play();
    key.classList.add('playing'); // adds the class of playing
    
  }
  function removeTransition(e) {
    if(e.propertyName != 'transform') return; // skip it if it's not transform
    this.classList.remove('playing')
  }
  const keys = document.querySelectorAll('.key');
  keys.forEach(key => key.addEventListener('transitionend', removeTransition))
  window.addEventListener("keydown", playSound); // doing it this way because we are using an array of elements
